# Hello Celo
A repo to get started with the exercise outline here: https://docs.celo.org/v/master/developer-guide/start/hellocelo
